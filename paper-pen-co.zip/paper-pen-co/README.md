# 🖊️ Paper & Pen Co. — Online Stationery Store

A complete stationery e-commerce website with:

- 🛍 **Shop** — Browse products with category filters and search
- 🛒 **Cart** — Add items, adjust quantities, view total
- 📦 **Checkout** — Fill delivery details (name, address, phone, etc.)
- 💳 **Payment** — Scan real Paytm QR code or pay via Google Pay / PhonePe / any UPI app
- ✅ **Order Confirmation** — Order ID generated, stored for admin
- ⚙️ **Admin Panel** — Add / Edit / Delete products (with image upload), view & manage all orders

## 💰 Payment Details
- **UPI ID:** 9035689664@ptaxis
- **Mobile:** 9035689664 (Sripriya R)
- Accepts: Paytm, Google Pay, PhonePe, BHIM, any UPI app

## 🚀 How to Deploy on GitHub Pages

1. Create a new GitHub repository (e.g. `paper-pen-co`)
2. Upload the files in this ZIP (just `index.html` is enough)
3. Go to **Settings → Pages**
4. Under **Source**, select `main` branch and `/ (root)`
5. Click **Save** — your site will be live at:
   `https://YOUR-USERNAME.github.io/paper-pen-co/`

## 📁 Files
- `index.html` — The complete website (shop + cart + checkout + payment + admin)
- `paytm-qr.png` — Your Paytm QR code image (already embedded in index.html)
- `README.md` — This file

## 🔐 Admin Panel
- Click the **⚙ Admin** button in the top navigation
- Switch between **Products** and **Orders** tabs
- All data is saved in browser storage (persists across sessions)
